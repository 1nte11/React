import Service from "./components/Service";
import ResultPosts from "./components/post/ResultPosts";



function App() {
  return (
    <div className="App">
      {/* <Service/> */}
      <ResultPosts/>
    </div>
  );
}

export default App;
