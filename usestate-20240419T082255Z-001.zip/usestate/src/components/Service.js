import { useState } from "react"


const Service=()=>{
    const [number, setNumber]=useState(0)
    const handlerFunction=()=>{
      
        setNumber(number+1)
        
    }
    return(
        <div>
            <button onClick={handlerFunction}>დააჭირე</button>
            <h2>{number}</h2>
        </div>
    )
}

export default Service

