import { useState } from "react"
import CurrentPosts from "./CurrentPost"
import InputPosts from "./InputPosts"

const ResultPosts=()=>{
    // const posts=[
    //     {
    //         first:"daviti",
    //         last:"botchorishvili"
    //     },
    //     {
    //         first:"ana",
    //         last:"botchorishvili"
    //     },
    // ]

    const [posts, setPosts]=useState([])

    const SubmitPost=(element)=>{
        console.log(element)
        setPosts(
            [
                ...posts,
                element
            ]
           
        )
    }
    return(

        <>

        <section>
            <InputPosts Addpost={SubmitPost}/>
        </section>

        <section>
            {
                posts.map((value)=>{
                    return(
                        <CurrentPosts firstname={value.first} lastname={value.last} />
                    )
                })
            }
        </section>
        </>
    )
}

export default ResultPosts