import { useState } from "react"


const InputPosts=({Addpost})=>{
    const [firstname, setFirstname]=useState('')
    const [lastname, setLastname]=useState('')

    const HandlerFirstName=(e)=>{
        setFirstname(e.currentTarget.value)
    }
    const HandlerLastName=(e)=>{
        setLastname(e.currentTarget.value)
    }

    const Submithandler=(event)=>{
        event.preventDefault()
        let objData={
            first:firstname,
            last:lastname
        }
        console.log(objData)
        Addpost(objData)
    }
    return(
        <form  onSubmit={Submithandler}>
            <input type="text" placeholder="firstname" onChange={HandlerFirstName}  />
            <input type="text" placeholder="LastName" onChange={HandlerLastName}  />
            <button type="submit">Click</button>
        </form>
    )
}

export default InputPosts