
const CurrentPosts=({firstname, lastname})=>{
    return(
      
             <div>
                <h2>{firstname}</h2>
                <p>{lastname}</p>
                <hr/>
            </div>
        
    )
}

export default CurrentPosts