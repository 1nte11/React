// import logo from './logo.svg';
// import './App.css';
import Navbar from './Components/Navbar/Navbar';
import Portfolio from './Components/Portfolio/Portfolio';
import ContactBox from './Components/Contact/ContactBox'
import Footer from './Components/footer/footer'

function App() {
  return (
    <div className="App">
  
   <Navbar />
    <Portfolio />
   <ContactBox /> 
   <Footer>
    <div style={{display:'flex', justifyContent:'space-around', alignItems:'center'}}>
    <div><img src={require('./Components/footer/icons.png')}></img></div>
    <p>© 2024 copyright all right reserved</p>
    </div>
   </Footer>
    </div>
  );
}

export default App;
