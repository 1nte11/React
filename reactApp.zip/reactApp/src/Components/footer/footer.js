import styled from "styled-components";
const Footer = styled.footer`
background-color: white;
height: 50px;
`

export default Footer;