import './Navbar.css'
import logo from './assets/logo.png';
import {StyledButton} from './NavbarButton.style';

const Navbar = ()=>{
    return(
        <div className='container'>
              <div className ='header'>
            <a href='#'><img src={logo}/></a>
            <ul>
            <li><a href='#'>Home</a></li>
            <li><a href='#'>Services</a></li>
            <li><a href='#'>Skills</a></li>
            <li><a href='#'>Portfolio</a></li>
            <li><a href='#'>Contact</a></li>
            </ul>
            <StyledButton><a href='#'>Contact Now</a></StyledButton>
          
   

        </div>
        </div>

    )
}

export default Navbar;
