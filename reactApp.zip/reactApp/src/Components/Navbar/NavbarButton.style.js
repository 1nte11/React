import styled from 'styled-components';

export const StyledButton = styled.button`
background-color: #f7af24;
border: 1px black scrollbar-width;
padding: 12px 28px;
font-size: 14px;
line-height: 1.5;
text-decoration: none;
font-weight: 600;
transition: ease all 0.35s;
display: inline-block;
`

