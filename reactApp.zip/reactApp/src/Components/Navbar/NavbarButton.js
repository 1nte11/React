import {StyledButton} from "./NavbarButton.style";

export default StyledButton;
