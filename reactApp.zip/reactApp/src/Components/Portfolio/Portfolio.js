import "./portfolio.css"
import Box, {PlainBox} from "./Box";


const Portfolio = ()=>{
    return(
    <>
        <div className="PortfolioContainer">
        <div className="portfolio">
            <h2>Latest Projects</h2>
           

           <div className="section">  
             <Box src={require('./Portfolio-assets/box1.jpg')} title='Agency Landing page' desc='Web/WordPress'/>
             <Box src={require('./Portfolio-assets/box2.jpg')}  title='Agency Landing page' desc='Web/WordPress'/>
             <Box src={require('./Portfolio-assets/box3.jpg')}  title='Agency Landing page' desc='Web/WordPress'/></div>
            
            <div className="section">  
             <Box src={require('./Portfolio-assets/box4.jpg')}  title='Agency Landing page' desc='Web/WordPress'/>
             <Box src={require('./Portfolio-assets/box5.jpg')}  title='Agency Landing page' desc='Web/WordPress'/>
             <Box src={require('./Portfolio-assets/box6.jpg')}  title='Agency Landing page' desc='Web/WordPress'/></div>
        </div>
        </div>

      <div className="ClientsWord">
        <h2>Client's Kind Word</h2>
       <div className="section clients"> 
       <PlainBox src={require('./Portfolio-assets/avatar1.jpg')} desc='Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s.' title='Jennifer Lutheran' />
       <PlainBox src={require('./Portfolio-assets/avatar2.jpg')} desc='Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s.' title='Jennifer Lutheran' />
       <PlainBox src={require('./Portfolio-assets/avatar3.jpg')} desc='Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s.' title='Jennifer Lutheran' />

        </div>

      </div>





    </>
      
    )
}

export default Portfolio;