import './portfolio.css'

const Box = (props)=>{
    return(
        <div className='box'>
        <div className='imgDiv'>
            <img src={props.src}/>
        </div>
        <div className='contentDiv'>
            <div className='descript'>
            <h3>{props.title}</h3>
            <p>{props.desc}</p>
            </div>
            <div><img className='arrow' src={require('./Portfolio-assets/arrow-right.png')}/></div>
        </div>
        </div>
           
    )
}

const PlainBox = (props) =>{
    return(
        <div className='box'>
        <div className='Clients-imgDiv'>
            <img src={props.src}/>
        </div>
        <div className='Clients-contentDiv'>
            <p>{props.desc}</p>
            <h6>{props.title}</h6>
        </div>
        </div>
           
    )
}


export default Box;
export {PlainBox};



