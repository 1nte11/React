import "./contact.css"
import Form from "./form"
import { StyledButton } from "../Navbar/NavbarButton.style"
import InfoStripe from "./InfoStripe"

const ContactBox = ()=>{

    return(
      <div className="ContactContainer"> 
      <h2>Let's Discuss Project</h2>
        <div className="content">
        <div className="formDiv">
            <h3>Get in Touch</h3>
            <p>Our Friendly team would love to hear from you</p> <br/>
        <Form/>
        <StyledButton id='btn'>Send Message</StyledButton>
        </div>
        <div className="Info">
            <InfoStripe path={require('./images/telephone.png')} title='Phone' value='+01 123 654 9087'/>
            <InfoStripe path={require('./images/circle.png')} title='Mail' value='info@domain.com'/>
            <InfoStripe path={require('./images/location.png')} title='Visit My Studio' value='Fl 2234 New York City'/> <br/>
            <img src={require('./images/back.png')}></img>


        </div>
        </div>


      </div>
    )
}

export default ContactBox;