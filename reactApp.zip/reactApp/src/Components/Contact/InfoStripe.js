
const InfoStripe = (props)=>{
    return(
        <div className="infostripe">
            <div className="img">
                <img src={props.path}></img>
            </div>
            <div className="infoDiv">
                <h6>{props.title}</h6>
                <p>{props.value}</p>
            </div>
        </div>
    )
}

export default InfoStripe;