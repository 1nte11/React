import './contact.css'
const Form = ()=>{
    return(
        <form className='form'>
        <div className='scope'>
        <div className="personal">            
        
        <label for='name'>First name</label><br></br>  
        <input type="text" placeholder="Name *" id='name' required></input><br/>
        </div>
        <div className='personal'>
        <label for='email'>Your Email</label> <br/>
        <input type="text" placeholder="Email *" id='email' required></input><br/>
        </div>
        </div>
    
            <div className='sub'>
            <label for='sub'>Subject</label> <br/>
            <input type="text" id='sub' placeholder="Subject *" required></input><br/>

            <label for='message'>Your Message</label><br/>
            <textarea id='message' placeholder="Your Message *" required></textarea>
            </div>

        </form>
    )
}

export default Form;