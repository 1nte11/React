import { useState } from "react"
import CurrentPosts from "./CurrentPost"
import InputPosts from "./InputPosts"

const ResultPosts=()=>{
    // const posts=[
    //     {
    //         first:"daviti",
    //         last:"botchorishvili"
    //     },
    //     {
    //         first:"ana",
    //         last:"botchorishvili"
    //     },
    // ]
    const [searchTerm,setSearchTerm]=useState("")
    const [posts, setPosts]=useState([])

    const SubmitPost=(element)=>{
        console.log(element)
        setPosts(
            [
                ...posts,
                element
            ]
           
        )
    }
    console.log(searchTerm);
    return(

        <>

        <section>
            <InputPosts Addpost={SubmitPost}/>
        </section>

        <section>
            <input type="text" placeholder="search by title" value={searchTerm} onChange={(event)=>{setSearchTerm(event.target.value)}} />
            {/* {searchTerm.length>0? 
            posts.map((value)=>{
                   return( value.first.includes(searchTerm)?<CurrentPosts firstname={value.first} lastname={value.last} />:null)
                }):
                posts.map((value)=>{
                    return(
                        <CurrentPosts firstname={value.first} lastname={value.last} />
                    )
                })
               
            } */}


            {/*  second  */}
            {
            posts.filter((item)=>{
                return searchTerm===''?item:item.first.includes(searchTerm)
            })
            .map((value)=>{
                    return(
                        <CurrentPosts firstname={value.first} lastname={value.last} />
                    )
                })

            }
        </section>
        </>
    )
}

export default ResultPosts