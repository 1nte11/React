import { useState } from "react";
import ResultPosts from "./components/post/ResultPosts";
function App() {
  // const [check, setcheck]=useState(true)
  // const [color, setcolor] = useState("black")
  // const [number, setnumber] = useState(0)
  // const handlerfunnction = ()=>{
  //   setcheck(
  //     false
  //   ) 
  //   setcolor(
  //     "pink"
  //   )
  //   setnumber(
  //     number+1
  //   )
  // }
  
  return (
    <div className="App">
      {/* {
          number===6?<p style={{backgroundColor:"red"}}>{number}</p>
          :
          <div>
            <button style={{backgroundColor:color}} type="button" onClick={handlerfunnction}>Click</button>
            <p style={{backgroundColor:"white"}}>{number}</p>
          </div>
      }
      {
        check? <p>lorem ipsum </p>:"hello"
      } */}
           <ResultPosts/>

    </div>
  );
}

export default App;
